import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Import translations
import translationRU from './locales/ru.json';
import translationEN from './locales/en.json';

// Initialize i18n
i18n
  .use(initReactI18next)
  .init({
    resources: {
      ru: {
        translation: translationRU,
      },
      en: {
        translation: translationEN,
      },
    },
    lng: 'ru', // Default language
    fallbackLng: 'ru',
    interpolation: {
      escapeValue: false, // React already protects from XSS
    },
  });

export default i18n;
export interface Property {
  id: string;
  title: string;
  type: 'a-frame' | 'glamp' | 'apartment' | 'cottage';
  location: {
    city: string;
    region: string;
    coordinates: [number, number]; // [latitude, longitude]
  };
  price: number;
  capacity: number;
  bedrooms: number;
  bathrooms: number;
  images: string[];
  description: string;
  amenities: string[];
  hostId: string;
  rating: number;
  reviewCount: number;
  isAvailable: boolean;
}

export interface Destination {
  id: string;
  name: string;
  region: string;
  image: string;
  propertyCount: number;
  coordinates: [number, number]; // [latitude, longitude]
}

export interface Host {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar?: string;
  properties: string[]; // Property IDs
  joinedDate: string;
  rating: number;
}

export interface Booking {
  id: string;
  propertyId: string;
  userId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  isHost: boolean;
  bookings: string[]; // Booking IDs
}

export interface SearchParams {
  location?: string;
  checkIn?: string;
  checkOut?: string;
  guests?: number;
  propertyType?: string;
}
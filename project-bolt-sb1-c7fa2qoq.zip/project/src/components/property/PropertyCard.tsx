import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Star, MapPin } from 'lucide-react';
import { Property } from '../../types';

interface PropertyCardProps {
  property: Property;
  featured?: boolean;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, featured = false }) => {
  const { t } = useTranslation();
  
  return (
    <div 
      className={`bg-white rounded-xl shadow-md overflow-hidden transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg ${
        featured ? 'transform scale-105' : ''
      }`}
    >
      <Link to={`/property/${property.id}`}>
        <div className="relative h-48 w-full overflow-hidden">
          <img
            src={property.images[0]}
            alt={property.title}
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
          />
          {featured && (
            <div className="absolute top-3 left-3 bg-secondary-600 text-white px-2 py-1 text-xs rounded-md">
              {t('home.featuredProperties.title')}
            </div>
          )}
        </div>
      </Link>
      
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <Link to={`/property/${property.id}`}>
              <h3 className="font-semibold text-lg line-clamp-1 hover:text-secondary-600 transition">
                {property.title}
              </h3>
            </Link>
            <div className="flex items-center mt-1 text-gray-500 text-sm">
              <MapPin size={14} className="mr-1" />
              <span>{property.location.city}, {property.location.region}</span>
            </div>
          </div>
          <div className="flex items-center space-x-1 bg-cream px-2 py-1 rounded-md">
            <Star size={14} className="text-yellow-500" />
            <span className="font-medium">{property.rating}</span>
          </div>
        </div>
        
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="text-xs bg-gray-100 px-2 py-1 rounded-md">
            {property.bedrooms} {property.bedrooms === 1 ? 'спальня' : 'спальни'}
          </span>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded-md">
            {property.bathrooms} {property.bathrooms === 1 ? 'ванная' : 'ванные'}
          </span>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded-md">
            {property.capacity} {property.capacity === 1 ? 'гость' : 'гостей'}
          </span>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div>
            <span className="font-semibold text-xl">₼{property.price}</span>
            <span className="text-gray-500 text-sm ml-1">{t('common.perNight')}</span>
          </div>
          <Link
            to={`/property/${property.id}`}
            className="bg-secondary-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-secondary-700 transition"
          >
            {t('common.bookNow')}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
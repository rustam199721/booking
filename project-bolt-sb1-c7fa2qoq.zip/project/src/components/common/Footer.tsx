import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Instagram, Facebook, Phone, Mail, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-forest-dark text-cream">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1: Logo and About */}
          <div>
            <Link to="/" className="text-2xl font-bold flex items-center mb-4">
              <div className="w-8 h-8 bg-secondary-500 rounded-full flex items-center justify-center mr-2">
                <span className="text-white text-xs font-semibold">AZ</span>
              </div>
              <span>AzStay</span>
            </Link>
            <p className="text-cream/80 mb-6">
              Откройте для себя лучшие загородные дома Азербайджана. Бронируйте A-frame дома, глэмпинги и уютные сельские квартиры для незабываемого отдыха.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream hover:text-secondary-400 transition"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cream hover:text-secondary-400 transition"
              >
                <Facebook size={20} />
              </a>
            </div>
          </div>

          {/* Column 2: Useful Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Ссылки</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/properties"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  {t('common.search')}
                </Link>
              </li>
              <li>
                <Link
                  to="/list-property"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  {t('home.hostSection.button')}
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  {t('common.aboutUs')}
                </Link>
              </li>
              <li>
                <Link
                  to="/privacy-policy"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  {t('common.privacyPolicy')}
                </Link>
              </li>
              <li>
                <Link
                  to="/terms"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  {t('common.termsOfService')}
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Popular Destinations */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Популярные направления</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/properties?location=Шеки"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  Шеки
                </Link>
              </li>
              <li>
                <Link
                  to="/properties?location=Габала"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  Габала
                </Link>
              </li>
              <li>
                <Link
                  to="/properties?location=Лахыдж"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  Лахыдж
                </Link>
              </li>
              <li>
                <Link
                  to="/properties?location=Шемаха"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  Шемаха
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">{t('common.contactUs')}</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 mt-1 text-secondary-400" />
                <span className="text-cream/80">
                  Baku White City, Office Building 3, 4th Floor, Baku, Azerbaijan
                </span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="mr-2 text-secondary-400" />
                <a
                  href="tel:+994501234567"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  +994 50 123 45 67
                </a>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="mr-2 text-secondary-400" />
                <a
                  href="mailto:info@azstay.az"
                  className="text-cream/80 hover:text-secondary-400 transition"
                >
                  info@azstay.az
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-cream/20 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-cream/60 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} AzStay. Все права защищены.
          </p>
          <div className="flex space-x-4">
            <Link
              to="/privacy-policy"
              className="text-cream/60 text-sm hover:text-secondary-400 transition"
            >
              {t('common.privacyPolicy')}
            </Link>
            <Link
              to="/terms"
              className="text-cream/60 text-sm hover:text-secondary-400 transition"
            >
              {t('common.termsOfService')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
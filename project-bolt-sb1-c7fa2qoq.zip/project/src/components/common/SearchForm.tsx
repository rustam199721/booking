import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Search, MapPin, Calendar, Users } from 'lucide-react';
import { SearchParams } from '../../types';

interface SearchFormProps {
  isHero?: boolean;
}

const SearchForm: React.FC<SearchFormProps> = ({ isHero = false }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  
  const [searchParams, setSearchParams] = useState<SearchParams>({
    location: '',
    checkIn: '',
    checkOut: '',
    guests: 2,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchParams(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    const queryParams = new URLSearchParams();
    
    if (searchParams.location) queryParams.set('location', searchParams.location);
    if (searchParams.checkIn) queryParams.set('checkIn', searchParams.checkIn);
    if (searchParams.checkOut) queryParams.set('checkOut', searchParams.checkOut);
    if (searchParams.guests) queryParams.set('guests', searchParams.guests.toString());
    
    navigate(`/properties?${queryParams.toString()}`);
  };

  return (
    <form
      onSubmit={handleSearch}
      className={`${
        isHero
          ? 'bg-white/95 backdrop-blur-md shadow-lg rounded-xl p-4 md:p-5'
          : 'bg-white shadow rounded-lg p-4'
      } w-full max-w-5xl mx-auto`}
    >
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Location */}
        <div className="relative">
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
            {t('home.search.location')}
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
              <MapPin size={18} />
            </span>
            <input
              type="text"
              id="location"
              name="location"
              value={searchParams.location}
              onChange={handleInputChange}
              placeholder={t('home.search.location')}
              className="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
            />
          </div>
        </div>

        {/* Check-in */}
        <div>
          <label htmlFor="checkIn" className="block text-sm font-medium text-gray-700 mb-1">
            {t('common.checkIn')}
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
              <Calendar size={18} />
            </span>
            <input
              type="date"
              id="checkIn"
              name="checkIn"
              value={searchParams.checkIn}
              onChange={handleInputChange}
              className="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
            />
          </div>
        </div>

        {/* Check-out */}
        <div>
          <label htmlFor="checkOut" className="block text-sm font-medium text-gray-700 mb-1">
            {t('common.checkOut')}
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
              <Calendar size={18} />
            </span>
            <input
              type="date"
              id="checkOut"
              name="checkOut"
              value={searchParams.checkOut}
              onChange={handleInputChange}
              className="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
            />
          </div>
        </div>

        {/* Guests */}
        <div>
          <label htmlFor="guests" className="block text-sm font-medium text-gray-700 mb-1">
            {t('common.guests')}
          </label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
              <Users size={18} />
            </span>
            <input
              type="number"
              id="guests"
              name="guests"
              min="1"
              max="10"
              value={searchParams.guests}
              onChange={handleInputChange}
              className="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        className={`${
          isHero 
            ? 'mt-4 w-full md:w-auto px-6 py-3 bg-secondary-600 text-white rounded-lg flex items-center justify-center hover:bg-secondary-700 transition'
            : 'mt-4 w-full bg-secondary-600 text-white py-2 rounded-lg hover:bg-secondary-700 transition'
        }`}
      >
        <Search size={18} className="mr-2" />
        {t('home.search.searchButton')}
      </button>
    </form>
  );
};

export default SearchForm;
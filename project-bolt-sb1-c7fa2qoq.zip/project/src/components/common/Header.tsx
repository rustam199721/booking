import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '../../context/LanguageContext';
import { Menu, X, Globe, User } from 'lucide-react';

const Header: React.FC = () => {
  const { t } = useTranslation();
  const { language, setLanguage } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ru' ? 'en' : 'ru');
  };

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    // Close menu when route changes
    setIsMenuOpen(false);
  }, [location]);

  const isHomePage = location.pathname === '/';

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled || !isHomePage
          ? 'bg-white shadow-md py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <Link
          to="/"
          className={`text-2xl font-bold ${
            isScrolled || !isHomePage ? 'text-forest-dark' : 'text-white'
          }`}
        >
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-secondary-600 rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-semibold">AZ</span>
            </div>
            <span className="hidden sm:inline">AzStay</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link
                  to="/properties"
                  className={`font-medium hover:text-secondary-600 transition ${
                    isScrolled || !isHomePage ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {t('common.search')}
                </Link>
              </li>
              <li>
                <Link
                  to="/list-property"
                  className={`font-medium hover:text-secondary-600 transition ${
                    isScrolled || !isHomePage ? 'text-gray-700' : 'text-white'
                  }`}
                >
                  {t('home.hostSection.button')}
                </Link>
              </li>
            </ul>
          </nav>
          
          <div className="flex items-center space-x-4">
            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center space-x-1 ${
                isScrolled || !isHomePage ? 'text-gray-700' : 'text-white'
              }`}
            >
              <Globe size={18} />
              <span className="text-sm font-medium">{language === 'ru' ? 'RU' : 'EN'}</span>
            </button>
            
            {/* User Menu */}
            <div className="relative">
              <button
                onClick={toggleDropdown}
                className={`flex items-center space-x-1 px-3 py-2 rounded-full border ${
                  isScrolled || !isHomePage
                    ? 'border-gray-300 text-gray-700'
                    : 'border-white text-white'
                }`}
              >
                <User size={18} />
                <span className="text-sm font-medium">{t('common.login')}</span>
              </button>
              
              {/* Dropdown */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl py-2 z-10">
                  <Link
                    to="/login"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    {t('common.login')}
                  </Link>
                  <Link
                    to="/register"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    {t('common.register')}
                  </Link>
                  <hr className="my-1" />
                  <Link
                    to="/extranet"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    {t('extranet.dashboard.title')}
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <button
          className={`md:hidden ${
            isScrolled || !isHomePage ? 'text-gray-700' : 'text-white'
          }`}
          onClick={toggleMenu}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-md">
          <div className="container mx-auto px-4 py-4">
            <nav>
              <ul className="space-y-4">
                <li>
                  <Link
                    to="/properties"
                    className="block text-gray-700 font-medium"
                  >
                    {t('common.search')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/list-property"
                    className="block text-gray-700 font-medium"
                  >
                    {t('home.hostSection.button')}
                  </Link>
                </li>
                <li>
                  <button
                    onClick={toggleLanguage}
                    className="flex items-center space-x-2 text-gray-700"
                  >
                    <Globe size={18} />
                    <span>
                      {language === 'ru'
                        ? t('common.russianLanguage')
                        : t('common.englishLanguage')}
                    </span>
                  </button>
                </li>
                <li>
                  <Link
                    to="/login"
                    className="block text-gray-700 font-medium"
                  >
                    {t('common.login')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/register"
                    className="block text-gray-700 font-medium"
                  >
                    {t('common.register')}
                  </Link>
                </li>
                <li>
                  <Link
                    to="/extranet"
                    className="block text-gray-700 font-medium"
                  >
                    {t('extranet.dashboard.title')}
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
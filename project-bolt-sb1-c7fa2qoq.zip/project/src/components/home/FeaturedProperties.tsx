import React from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import PropertyCard from '../property/PropertyCard';
import { properties } from '../../data/properties';

const FeaturedProperties: React.FC = () => {
  const { t } = useTranslation();
  
  // Get top 3 properties based on rating
  const featuredProperties = [...properties]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3);

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-forest-dark mb-3">
            {t('home.featuredProperties.title')}
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('home.featuredProperties.subtitle')}
          </p>
        </div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {featuredProperties.map((property) => (
            <motion.div key={property.id} variants={item}>
              <PropertyCard property={property} featured={true} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturedProperties;
import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Home } from 'lucide-react';
import { destinations } from '../../data/destinations';

const PopularDestinations: React.FC = () => {
  const { t } = useTranslation();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section className="py-16 bg-cream">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-forest-dark mb-3">
            {t('home.popularDestinations.title')}
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('home.popularDestinations.subtitle')}
          </p>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {destinations.map((destination) => (
            <motion.div key={destination.id} variants={item}>
              <Link 
                to={`/properties?location=${destination.name}`}
                className="group block"
              >
                <div className="relative rounded-xl overflow-hidden h-64 shadow-md">
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/70 z-10"></div>
                  <img 
                    src={destination.image} 
                    alt={destination.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute bottom-0 left-0 right-0 z-20 p-4 text-white">
                    <h3 className="text-xl font-semibold mb-1">{destination.name}</h3>
                    <div className="flex items-center text-white/90 text-sm">
                      <Home size={14} className="mr-1" />
                      <span>{destination.propertyCount} {t('common.night')}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-10">
          <Link 
            to="/properties" 
            className="inline-block px-6 py-3 bg-transparent border border-secondary-600 text-secondary-600 rounded-lg font-medium hover:bg-secondary-600 hover:text-white transition duration-300"
          >
            {t('home.popularDestinations.viewAll')}
          </Link>
        </div>
      </div>
    </section>
  );
};

export default PopularDestinations;
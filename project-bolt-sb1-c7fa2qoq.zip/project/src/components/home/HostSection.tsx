import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { TrendingUp } from 'lucide-react';

const HostSection: React.FC = () => {
  const { t } = useTranslation();

  return (
    <section className="py-16 bg-secondary-600 text-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-4">{t('home.hostSection.title')}</h2>
            <p className="text-white/90 mb-6 text-lg">
              {t('home.hostSection.subtitle')}
            </p>
            <div className="flex items-center p-4 bg-white/10 backdrop-blur-sm rounded-lg mb-6">
              <TrendingUp className="text-cream mr-3" size={24} />
              <span className="text-cream">{t('home.hostSection.earning')}</span>
            </div>
            <Link
              to="/list-property"
              className="inline-block px-6 py-3 bg-white text-secondary-600 rounded-lg font-semibold hover:bg-cream transition duration-300"
            >
              {t('home.hostSection.button')}
            </Link>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-xl overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/2119714/pexels-photo-2119714.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Host your property"
                className="w-full h-full object-cover rounded-xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="bg-white/90 backdrop-blur-sm p-4 rounded-lg">
                  <p className="text-forest-dark font-semibold">
                    "После того, как я разместил свой коттедж на AzStay, я смог увеличить доход от аренды на 40%!"
                  </p>
                  <div className="mt-2 text-forest-dark/70 text-sm">
                    - Эмиль С., хозяин коттеджа в Габале
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-16 h-16 bg-cream rounded-full opacity-50"></div>
            <div className="absolute -bottom-4 -left-4 w-10 h-10 bg-forest-light rounded-full opacity-50"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HostSection;
import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';

const PropertyTypes: React.FC = () => {
  const { t } = useTranslation();

  const propertyTypes = [
    {
      id: 'a-frame',
      name: t('home.propertyTypes.aFrames'),
      image: 'https://images.pexels.com/photos/803975/pexels-photo-803975.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      count: 12,
    },
    {
      id: 'glamp',
      name: t('home.propertyTypes.glamping'),
      image: 'https://images.pexels.com/photos/5364980/pexels-photo-5364980.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      count: 8,
    },
    {
      id: 'apartment',
      name: t('home.propertyTypes.apartments'),
      image: 'https://images.pexels.com/photos/3316923/pexels-photo-3316923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      count: 15,
    },
    {
      id: 'cottage',
      name: t('home.propertyTypes.cottages'),
      image: 'https://images.pexels.com/photos/2635038/pexels-photo-2635038.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      count: 10,
    },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section className="py-16 bg-forest-light/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-forest-dark mb-3">
            {t('home.propertyTypes.title')}
          </h2>
        </div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {propertyTypes.map((type) => (
            <motion.div key={type.id} variants={item}>
              <Link 
                to={`/properties?propertyType=${type.id}`}
                className="group block"
              >
                <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition duration-300">
                  <div className="h-44 overflow-hidden">
                    <img 
                      src={type.image} 
                      alt={type.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-forest-dark group-hover:text-secondary-600 transition">
                      {type.name}
                    </h3>
                    <p className="text-gray-500 text-sm">{type.count} объектов</p>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default PropertyTypes;
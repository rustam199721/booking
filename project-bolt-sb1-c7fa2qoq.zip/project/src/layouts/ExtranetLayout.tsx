import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';

// In a real application, this would check if the user is authenticated
const isAuthenticated = true; // Mock authentication status

const ExtranetLayout: React.FC = () => {
  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/extranet/login" replace />;
  }

  return <Outlet />;
};

export default ExtranetLayout;
import { Destination } from '../types';

export const destinations: Destination[] = [
  {
    id: '1',
    name: 'Шеки',
    region: 'Шекинский район',
    image: 'https://images.pexels.com/photos/5191371/pexels-photo-5191371.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    propertyCount: 12,
    coordinates: [41.1925, 47.1712],
  },
  {
    id: '2',
    name: 'Габала',
    region: 'Габалинский район',
    image: 'https://images.pexels.com/photos/11284236/pexels-photo-11284236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    propertyCount: 18,
    coordinates: [40.9800, 47.8500],
  },
  {
    id: '3',
    name: 'Лахыдж',
    region: 'Исмаиллинский район',
    image: 'https://images.pexels.com/photos/10267632/pexels-photo-10267632.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    propertyCount: 5,
    coordinates: [40.8444, 48.3953],
  },
  {
    id: '4',
    name: 'Шемаха',
    region: 'Шемахинский район',
    image: 'https://images.pexels.com/photos/6261178/pexels-photo-6261178.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    propertyCount: 8,
    coordinates: [40.6320, 48.6361],
  },
];
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import './i18n';

// Layouts
import MainLayout from './layouts/MainLayout';
import ExtranetLayout from './layouts/ExtranetLayout';

// Pages
import Home from './pages/Home';
import PropertyDetails from './pages/PropertyDetails';
import PropertiesListing from './pages/PropertiesListing';
import ListYourProperty from './pages/ListYourProperty';
import ExtranetLogin from './pages/extranet/Login';
import ExtranetDashboard from './pages/extranet/Dashboard';

function App() {
  return (
    <LanguageProvider>
      <Router>
        <Routes>
          {/* Main website routes */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Home />} />
            <Route path="property/:id" element={<PropertyDetails />} />
            <Route path="properties" element={<PropertiesListing />} />
            <Route path="list-property" element={<ListYourProperty />} />
          </Route>
          
          {/* Extranet routes */}
          <Route path="/extranet/login" element={<ExtranetLogin />} />
          <Route path="/extranet" element={<ExtranetLayout />}>
            <Route index element={<ExtranetDashboard />} />
            {/* Additional extranet routes will be added here */}
          </Route>
        </Routes>
      </Router>
    </LanguageProvider>
  );
}

export default App;
import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  Home, 
  Calendar, 
  Users, 
  Settings, 
  LogOut,
  DollarSign,
  TrendingUp,
  Bell,
  MessageSquare,
  ClipboardList,
  ChevronRight,
  Percent,
  Star
} from 'lucide-react';

const ExtranetDashboard: React.FC = () => {
  const { t } = useTranslation();

  const sidebarItems = [
    { icon: <Home size={20} />, label: t('extranet.dashboard.title'), path: '/extranet' },
    { icon: <ClipboardList size={20} />, label: t('extranet.listings.title'), path: '/extranet/listings' },
    { icon: <Calendar size={20} />, label: t('extranet.bookings.title'), path: '/extranet/bookings' },
    { icon: <MessageSquare size={20} />, label: 'Сообщения', path: '/extranet/messages' },
    { icon: <DollarSign size={20} />, label: 'Финансы', path: '/extranet/finances' },
    { icon: <Users size={20} />, label: 'Гости', path: '/extranet/guests' },
    { icon: <Settings size={20} />, label: t('extranet.settings.title'), path: '/extranet/settings' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md hidden md:flex flex-col">
        <div className="p-4 border-b">
          <Link to="/" className="flex items-center text-xl font-bold text-forest-dark">
            <div className="w-8 h-8 bg-secondary-600 rounded-full flex items-center justify-center mr-2">
              <span className="text-white text-xs font-semibold">AZ</span>
            </div>
            <span>AzStay</span>
          </Link>
        </div>
        
        <div className="p-4 border-b">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-secondary-100 rounded-full flex items-center justify-center mr-3">
              <span className="text-secondary-600 font-semibold">ИК</span>
            </div>
            <div>
              <p className="font-medium text-gray-800">Ильгар Керимов</p>
              <p className="text-gray-500 text-sm">ilgar@example.com</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          {sidebarItems.map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition ${
                index === 0
                  ? 'bg-secondary-100 text-secondary-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <span className={index === 0 ? 'text-secondary-600' : ''}>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t">
          <button className="flex items-center space-x-3 px-3 py-2 w-full rounded-lg text-gray-600 hover:bg-gray-100 transition">
            <LogOut size={20} />
            <span>{t('common.logout')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white shadow-sm p-4 sticky top-0 z-10">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold text-forest-dark md:hidden">AzStay</h1>
            <div className="flex items-center space-x-4">
              <button className="text-gray-600 hover:text-gray-800 transition">
                <Bell size={20} />
              </button>
              <div className="w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center md:hidden">
                <span className="text-secondary-600 font-semibold text-xs">ИК</span>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-4 md:p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-forest-dark mb-1">
              {t('extranet.dashboard.welcomeBack')}, Ильгар
            </h1>
            <p className="text-gray-600">Вот обзор вашей деятельности</p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-500">{t('extranet.dashboard.totalBookings')}</p>
                  <p className="text-2xl font-bold mt-1">12</p>
                </div>
                <div className="p-2 bg-blue-50 rounded-lg text-blue-500">
                  <ClipboardList size={22} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-green-600 text-sm">
                <TrendingUp size={16} className="mr-1" />
                <span>16% по сравнению с прошлым месяцем</span>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-500">{t('extranet.dashboard.pendingBookings')}</p>
                  <p className="text-2xl font-bold mt-1">3</p>
                </div>
                <div className="p-2 bg-orange-50 rounded-lg text-orange-500">
                  <Calendar size={22} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-red-500 text-sm">
                <TrendingUp size={16} className="mr-1" />
                <span>5% ожидают подтверждения</span>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-500">{t('extranet.dashboard.totalEarnings')}</p>
                  <p className="text-2xl font-bold mt-1">₼4,250</p>
                </div>
                <div className="p-2 bg-green-50 rounded-lg text-green-500">
                  <DollarSign size={22} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-green-600 text-sm">
                <TrendingUp size={16} className="mr-1" />
                <span>23% по сравнению с прошлым месяцем</span>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-gray-500">{t('extranet.dashboard.occupancyRate')}</p>
                  <p className="text-2xl font-bold mt-1">68%</p>
                </div>
                <div className="p-2 bg-purple-50 rounded-lg text-purple-500">
                  <Percent size={22} />
                </div>
              </div>
              <div className="flex items-center mt-4 text-green-600 text-sm">
                <TrendingUp size={16} className="mr-1" />
                <span>8% по сравнению с прошлым месяцем</span>
              </div>
            </div>
          </div>

          {/* Recent Bookings */}
          <div className="bg-white rounded-xl shadow-sm mb-8">
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="font-semibold text-lg text-forest-dark">Последние бронирования</h2>
              <Link to="/extranet/bookings" className="text-secondary-600 text-sm hover:underline flex items-center">
                Смотреть все <ChevronRight size={16} />
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-gray-500 text-sm">
                    <th className="p-4 font-medium">Гость</th>
                    <th className="p-4 font-medium">Объект</th>
                    <th className="p-4 font-medium">Даты</th>
                    <th className="p-4 font-medium">Статус</th>
                    <th className="p-4 font-medium">Сумма</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                          <span className="text-blue-600 font-semibold text-xs">АМ</span>
                        </div>
                        <span>Айнур Мамедова</span>
                      </div>
                    </td>
                    <td className="p-4">Современный A-Frame с видом на горы</td>
                    <td className="p-4">01.07.2025 - 05.07.2025</td>
                    <td className="p-4">
                      <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                        Подтверждено
                      </span>
                    </td>
                    <td className="p-4 font-medium">₼600</td>
                  </tr>
                  <tr className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mr-3">
                          <span className="text-yellow-600 font-semibold text-xs">ФН</span>
                        </div>
                        <span>Фарид Насиров</span>
                      </div>
                    </td>
                    <td className="p-4">Глэмпинг в яблоневом саду</td>
                    <td className="p-4">15.07.2025 - 17.07.2025</td>
                    <td className="p-4">
                      <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs">
                        Ожидает
                      </span>
                    </td>
                    <td className="p-4 font-medium">₼390</td>
                  </tr>
                  <tr className="border-t hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                          <span className="text-green-600 font-semibold text-xs">ЛГ</span>
                        </div>
                        <span>Лейла Гасанова</span>
                      </div>
                    </td>
                    <td className="p-4">Уютный A-Frame на берегу озера</td>
                    <td className="p-4">10.08.2025 - 15.08.2025</td>
                    <td className="p-4">
                      <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">
                        Подтверждено
                      </span>
                    </td>
                    <td className="p-4 font-medium">₼700</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* My Properties */}
          <div className="bg-white rounded-xl shadow-sm">
            <div className="flex justify-between items-center p-4 border-b">
              <h2 className="font-semibold text-lg text-forest-dark">Мои объекты</h2>
              <Link to="/extranet/listings" className="text-secondary-600 text-sm hover:underline flex items-center">
                Смотреть все <ChevronRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
              <div className="border rounded-lg overflow-hidden hover:shadow-md transition">
                <div className="h-40 overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/803975/pexels-photo-803975.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                    alt="Property"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-2">Современный A-Frame с видом на горы</h3>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-gray-500 text-sm">Шеки, Шекинский район</div>
                    <div className="flex items-center text-yellow-500">
                      <Star size={16} className="mr-1" />
                      <span>4.8</span>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Загрузка</span>
                    <span className="text-green-600">75%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div className="bg-green-600 h-1.5 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg overflow-hidden hover:shadow-md transition">
                <div className="h-40 overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/5364980/pexels-photo-5364980.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                    alt="Property"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium mb-2">Глэмпинг в яблоневом саду</h3>
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-gray-500 text-sm">Губа, Губинский район</div>
                    <div className="flex items-center text-yellow-500">
                      <Star size={16} className="mr-1" />
                      <span>4.8</span>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Загрузка</span>
                    <span className="text-green-600">60%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div className="bg-green-600 h-1.5 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ExtranetDashboard;
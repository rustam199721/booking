import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { LogIn, Lock, Mail, Eye, EyeOff } from 'lucide-react';

const ExtranetLogin: React.FC = () => {
  const { t } = useTranslation();
  const [showPassword, setShowPassword] = useState(false);
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
    remember: false,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setLoginData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, would handle login here
    console.log('Login data:', loginData);
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex items-center justify-center p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full"
        >
          <div className="text-center mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-2xl font-bold text-forest-dark"
            >
              <div className="w-8 h-8 bg-secondary-600 rounded-full flex items-center justify-center mr-2">
                <span className="text-white text-xs font-semibold">AZ</span>
              </div>
              <span>AzStay</span>
            </Link>
            <h1 className="text-2xl font-bold text-forest-dark mt-6 mb-2">
              {t('extranet.dashboard.title')}
            </h1>
            <p className="text-gray-600">
              Войдите в свой аккаунт для управления объявлениями
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Электронная почта
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                  <Mail size={18} />
                </span>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={loginData.email}
                  onChange={handleInputChange}
                  required
                  className="pl-10 pr-3 py-3 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                  placeholder="name@example.com"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Пароль
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                  <Lock size={18} />
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={loginData.password}
                  onChange={handleInputChange}
                  required
                  className="pl-10 pr-10 py-3 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={togglePasswordVisibility}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  name="remember"
                  checked={loginData.remember}
                  onChange={handleInputChange}
                  className="rounded text-secondary-600 focus:ring-secondary-400 mr-2"
                />
                <span className="text-gray-700 text-sm">Запомнить меня</span>
              </label>
              <a href="#" className="text-secondary-600 hover:text-secondary-700 text-sm">
                Забыли пароль?
              </a>
            </div>

            <button
              type="submit"
              className="w-full bg-secondary-600 text-white py-3 rounded-lg font-medium hover:bg-secondary-700 transition flex items-center justify-center"
            >
              <LogIn size={18} className="mr-2" />
              Войти
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-600">
              Нет аккаунта?{' '}
              <Link to="/list-property" className="text-secondary-600 hover:text-secondary-700">
                Зарегистрируйтесь
              </Link>
            </p>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Image */}
      <div className="hidden lg:block lg:w-1/2 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent z-10"></div>
        <img
          src="https://images.pexels.com/photos/5364980/pexels-photo-5364980.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Countryside accommodation"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 flex items-center z-20 p-12">
          <div className="text-white max-w-lg">
            <h2 className="text-3xl font-bold mb-4">Управляйте своей недвижимостью с комфортом</h2>
            <p className="text-white/90 text-lg">
              Получайте доступ к бронированиям, управляйте календарем и отвечайте гостям — всё в одном месте.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExtranetLogin;
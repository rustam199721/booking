import React from 'react';
import Hero from '../components/home/Hero';
import PopularDestinations from '../components/home/PopularDestinations';
import FeaturedProperties from '../components/home/FeaturedProperties';
import PropertyTypes from '../components/home/PropertyTypes';
import HostSection from '../components/home/HostSection';

const Home: React.FC = () => {
  return (
    <div>
      <Hero />
      <PopularDestinations />
      <FeaturedProperties />
      <PropertyTypes />
      <HostSection />
    </div>
  );
};

export default Home;
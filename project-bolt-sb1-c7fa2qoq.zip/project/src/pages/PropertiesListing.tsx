import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Filter, MapPin } from 'lucide-react';
import PropertyCard from '../components/property/PropertyCard';
import SearchForm from '../components/common/SearchForm';
import { properties } from '../data/properties';
import { Property } from '../types';

const PropertiesListing: React.FC = () => {
  const { t } = useTranslation();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  
  const [filteredProperties, setFilteredProperties] = useState<Property[]>(properties);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    priceMin: 0,
    priceMax: 500,
    bedrooms: 0,
    propertyType: queryParams.get('propertyType') || 'all',
    location: queryParams.get('location') || '',
  });

  useEffect(() => {
    // Update location filter when URL changes
    setFilters(prev => ({
      ...prev,
      location: queryParams.get('location') || prev.location,
      propertyType: queryParams.get('propertyType') || prev.propertyType,
    }));
  }, [location.search]);

  useEffect(() => {
    // Apply filters
    let result = [...properties];
    
    // Filter by location
    if (filters.location) {
      result = result.filter(
        (property) => 
          property.location.city.toLowerCase().includes(filters.location.toLowerCase()) ||
          property.location.region.toLowerCase().includes(filters.location.toLowerCase())
      );
    }
    
    // Filter by property type
    if (filters.propertyType !== 'all') {
      result = result.filter((property) => property.type === filters.propertyType);
    }
    
    // Filter by price
    result = result.filter(
      (property) => property.price >= filters.priceMin && property.price <= filters.priceMax
    );
    
    // Filter by bedrooms
    if (filters.bedrooms > 0) {
      result = result.filter((property) => property.bedrooms >= filters.bedrooms);
    }
    
    setFilteredProperties(result);
  }, [filters]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: name === 'priceMin' || name === 'priceMax' || name === 'bedrooms' ? Number(value) : value,
    }));
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="pt-24 pb-16 bg-cream/50 min-h-screen">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-forest-dark mb-4">
            {filters.location
              ? `Размещение в ${filters.location}`
              : filters.propertyType !== 'all'
              ? `${filters.propertyType === 'a-frame' ? 'A-frame дома' : 
                  filters.propertyType === 'glamp' ? 'Глэмпинги' : 
                  filters.propertyType === 'apartment' ? 'Апартаменты' : 'Коттеджи'}`
              : 'Все варианты размещения'}
          </h1>
          
          {/* Search Form */}
          <div className="mb-6">
            <SearchForm />
          </div>
          
          {/* Filters */}
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Filter size={20} className="mr-2 text-forest-dark" />
                <h2 className="text-lg font-semibold text-forest-dark">Фильтры</h2>
              </div>
              <button
                onClick={toggleFilters}
                className="text-secondary-600 hover:text-secondary-700 font-medium flex items-center"
              >
                {showFilters ? 'Скрыть фильтры' : 'Показать фильтры'}
              </button>
            </div>
            
            {showFilters && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label htmlFor="propertyType" className="block text-sm font-medium text-gray-700 mb-1">
                    Тип жилья
                  </label>
                  <select
                    id="propertyType"
                    name="propertyType"
                    value={filters.propertyType}
                    onChange={handleFilterChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-3 focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                  >
                    <option value="all">Все типы</option>
                    <option value="a-frame">A-frame дома</option>
                    <option value="glamp">Глэмпинги</option>
                    <option value="apartment">Апартаменты</option>
                    <option value="cottage">Коттеджи</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="bedrooms" className="block text-sm font-medium text-gray-700 mb-1">
                    Спальни (мин.)
                  </label>
                  <select
                    id="bedrooms"
                    name="bedrooms"
                    value={filters.bedrooms}
                    onChange={handleFilterChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-3 focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                  >
                    <option value="0">Любое количество</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Цена за ночь
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <input
                        type="number"
                        name="priceMin"
                        value={filters.priceMin}
                        onChange={handleFilterChange}
                        min="0"
                        max="1000"
                        placeholder="Мин."
                        className="w-full border border-gray-300 rounded-lg py-2 px-3 focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                      />
                    </div>
                    <div>
                      <input
                        type="number"
                        name="priceMax"
                        value={filters.priceMax}
                        onChange={handleFilterChange}
                        min="0"
                        max="1000"
                        placeholder="Макс."
                        className="w-full border border-gray-300 rounded-lg py-2 px-3 focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Results stats */}
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-600">
              Найдено: <span className="font-semibold">{filteredProperties.length}</span> вариантов
            </p>
            {filters.location && (
              <div className="flex items-center text-gray-600">
                <MapPin size={16} className="mr-1" />
                <span>{filters.location}</span>
              </div>
            )}
          </div>
        </div>
        
        {/* Property Grid */}
        {filteredProperties.length > 0 ? (
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredProperties.map((property) => (
              <motion.div key={property.id} variants={item}>
                <PropertyCard property={property} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Жилье не найдено
            </h3>
            <p className="text-gray-600 mb-6">
              Попробуйте изменить параметры поиска или фильтры
            </p>
            <button
              onClick={() => setFilters({
                priceMin: 0,
                priceMax: 500,
                bedrooms: 0,
                propertyType: 'all',
                location: '',
              })}
              className="bg-secondary-600 text-white px-4 py-2 rounded-lg hover:bg-secondary-700 transition"
            >
              Сбросить все фильтры
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertiesListing;
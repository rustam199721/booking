import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Star, 
  Home,
  Bed,
  Bath,
  ChevronLeft,
  ChevronRight,
  Wifi,
  Coffee,
  Wind,
  Tv,
  UtensilsCrossed
} from 'lucide-react';
import { properties } from '../data/properties';
import PropertyCard from '../components/property/PropertyCard';

const PropertyDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showAllImages, setShowAllImages] = useState(false);

  // Find the property with the matching ID
  const property = properties.find((p) => p.id === id);

  // Get similar properties (same type or location)
  const similarProperties = property
    ? properties
        .filter(
          (p) =>
            (p.type === property.type || p.location.city === property.location.city) &&
            p.id !== property.id
        )
        .slice(0, 3)
    : [];

  if (!property) {
    return <div className="container mx-auto px-4 py-16">Property not found</div>;
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) =>
      prev === property.images.length - 1 ? 0 : prev + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? property.images.length - 1 : prev - 1
    );
  };

  const amenityIcons: Record<string, React.ReactNode> = {
    'Wi-Fi': <Wifi size={20} />,
    'Камин': <Home size={20} />,
    'Кухня': <UtensilsCrossed size={20} />,
    'Завтрак': <Coffee size={20} />,
    'Кондиционер': <Wind size={20} />,
    'Телевизор': <Tv size={20} />,
  };

  return (
    <div className="pt-20 pb-16">
      {/* Gallery */}
      <div className="relative">
        {!showAllImages ? (
          <div className="relative h-[50vh] md:h-[60vh]">
            <img
              src={property.images[currentImageIndex]}
              alt={property.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-4 right-4">
              <button
                onClick={() => setShowAllImages(true)}
                className="bg-white/90 backdrop-blur-sm text-forest-dark px-4 py-2 rounded-lg shadow-md hover:bg-white transition"
              >
                {t('property.showAllPhotos')}
              </button>
            </div>
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm p-2 rounded-full shadow-md hover:bg-white transition"
            >
              <ChevronLeft size={24} className="text-forest-dark" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 backdrop-blur-sm p-2 rounded-full shadow-md hover:bg-white transition"
            >
              <ChevronRight size={24} className="text-forest-dark" />
            </button>
          </div>
        ) : (
          <div className="fixed inset-0 bg-black z-50 overflow-auto">
            <div className="p-4">
              <button
                onClick={() => setShowAllImages(false)}
                className="bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-lg mb-4 hover:bg-white/30 transition"
              >
                &times; Close
              </button>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {property.images.map((image, index) => (
                  <div key={index} className="w-full">
                    <img
                      src={image}
                      alt={`${property.title} - ${index + 1}`}
                      className="w-full rounded-lg"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="container mx-auto px-4 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold text-forest-dark">{property.title}</h1>
                <div className="flex items-center mt-2 text-gray-600">
                  <MapPin size={18} className="mr-1" />
                  <span>
                    {property.location.city}, {property.location.region}
                  </span>
                </div>
              </div>
              <div className="flex items-center bg-cream px-3 py-2 rounded-lg">
                <Star size={18} className="text-yellow-600 mr-1" />
                <span className="font-semibold">{property.rating}</span>
                <span className="text-gray-600 ml-1">({property.reviewCount})</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-4 mt-6">
              <div className="flex items-center bg-gray-100 px-4 py-2 rounded-lg">
                <Home size={18} className="text-forest-dark mr-2" />
                <span>{property.type === 'a-frame' ? 'A-frame' : property.type}</span>
              </div>
              <div className="flex items-center bg-gray-100 px-4 py-2 rounded-lg">
                <Bed size={18} className="text-forest-dark mr-2" />
                <span>{property.bedrooms} спальни</span>
              </div>
              <div className="flex items-center bg-gray-100 px-4 py-2 rounded-lg">
                <Bath size={18} className="text-forest-dark mr-2" />
                <span>{property.bathrooms} ванные</span>
              </div>
              <div className="flex items-center bg-gray-100 px-4 py-2 rounded-lg">
                <Users size={18} className="text-forest-dark mr-2" />
                <span>До {property.capacity} гостей</span>
              </div>
            </div>

            <div className="mt-8">
              <h2 className="text-xl font-semibold text-forest-dark mb-4">
                {t('property.aboutProperty')}
              </h2>
              <p className="text-gray-700 leading-relaxed">{property.description}</p>
            </div>

            <div className="mt-8">
              <h2 className="text-xl font-semibold text-forest-dark mb-4">
                {t('property.amenities')}
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {property.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center">
                    <div className="text-forest-dark mr-2">
                      {amenityIcons[amenity] || <Home size={20} />}
                    </div>
                    <span>{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <h2 className="text-xl font-semibold text-forest-dark mb-4">
                {t('property.location')}
              </h2>
              <div className="h-[300px] rounded-lg overflow-hidden">
                <MapContainer 
                  center={property.location.coordinates} 
                  zoom={13} 
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  />
                  <Marker position={property.location.coordinates}>
                    <Popup>{property.title}</Popup>
                  </Marker>
                </MapContainer>
              </div>
              <p className="mt-2 text-gray-600">
                {property.location.city}, {property.location.region}
              </p>
            </div>
          </div>

          {/* Booking Form */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-lg p-6 sticky top-24"
            >
              <div className="flex justify-between items-center mb-6">
                <div>
                  <span className="text-2xl font-bold text-forest-dark">₼{property.price}</span>
                  <span className="text-gray-600 ml-1">{t('common.perNight')}</span>
                </div>
                <div className="flex items-center text-yellow-600">
                  <Star size={16} className="mr-1" />
                  <span>{property.rating}</span>
                </div>
              </div>

              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label htmlFor="checkIn" className="block text-sm font-medium text-gray-700 mb-1">
                      {t('common.checkIn')}
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                        <Calendar size={16} />
                      </span>
                      <input
                        type="date"
                        id="checkIn"
                        className="pl-9 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="checkOut" className="block text-sm font-medium text-gray-700 mb-1">
                      {t('common.checkOut')}
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                        <Calendar size={16} />
                      </span>
                      <input
                        type="date"
                        id="checkOut"
                        className="pl-9 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="guests" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('common.guests')}
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                      <Users size={16} />
                    </span>
                    <select
                      id="guests"
                      className="pl-9 pr-3 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-400 focus:border-secondary-400 transition"
                    >
                      {[...Array(property.capacity)].map((_, i) => (
                        <option key={i} value={i + 1}>
                          {i + 1} {i === 0 ? t('common.guests') : t('common.guests')}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-secondary-600 text-white py-3 rounded-lg font-medium hover:bg-secondary-700 transition"
                >
                  {t('common.bookNow')}
                </button>
              </form>

              <div className="mt-6 border-t pt-4">
                <div className="flex justify-between mb-2">
                  <span>₼{property.price} x 5 {t('common.nights')}</span>
                  <span>₼{property.price * 5}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Сервисный сбор</span>
                  <span>₼{Math.round(property.price * 5 * 0.1)}</span>
                </div>
                <div className="flex justify-between font-semibold text-lg pt-2 border-t mt-2">
                  <span>{t('common.total')}</span>
                  <span>₼{property.price * 5 + Math.round(property.price * 5 * 0.1)}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Similar Properties */}
        {similarProperties.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-forest-dark mb-6">
              {t('property.similarProperties')}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarProperties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PropertyDetails;